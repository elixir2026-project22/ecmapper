"""Assemble MLL Global Placement Directions v2.

Inputs : points.json (extract.py), vocab.py, knowledge.py, legacy_map.py, legacy v1 JSON
Outputs: placement_directions_v2.json, consensus_pairs.csv
"""
import collections, csv, json, math, os, sys
import numpy as np
from scipy.spatial import Delaunay

sys.path.insert(0, os.path.dirname(__file__))
import vocab, knowledge, legacy_map

W = "/home/claude"
OUT = "/mnt/user-data/outputs"
ENT = vocab.build_entities()

# ------------------------------------------------------------------ vocabulary
ROLE_OVERRIDE = {
    "glycolysis_gluconeogenesis": "central", "tca_cycle": "central", "pentose_phosphate_pathway": "central",
    "pyruvate_metabolism": "central", "glyoxylate_dicarboxylate_metabolism": "central", "glycolysis": "central",
    "central_carbon_metabolism": "central", "gluconeogenesis": "biosynthesis",
}
for e in ENT.values():
    i, cat = e["id"], None
    if e["id"] in ROLE_OVERRIDE:
        role = ROLE_OVERRIDE[i]
    elif e["type"] in ("category", "metabolite_hub"):
        role = None
    elif "energy_metabolism" in e["part_of"] or i in ("respiratory_electron_transport", "atp_synthase",
                                                      "photosynthetic_electron_transport", "anaerobic_respiration"):
        role = "energy"
    elif "transport_and_shuttles" in e["part_of"] or "shuttle" in i:
        role = "transport"
    elif any(k in i for k in ("degradation", "lipolysis", "beta_oxidation", "fermentation", "recycling", "salvage")):
        role = "degradation"
    elif any(k in i for k in ("biosynthesis", "synthesis", "elongation", "assimilation", "fixation", "_cycle")):
        role = "biosynthesis"
    else:
        role = "interconversion"
    e["process_role"] = role

aliases = collections.defaultdict(set)
for name, v in vocab.HUMAN_GEM.items():
    if v: aliases[v].add(f"Human-GEM: {name}")
for name, v in vocab.IJO1366.items():
    if v: aliases[v].add(f"iJO1366: {name}")
for name, v in vocab.FAME_SYNECHOCYSTIS.items():
    if v: aliases[v].add(f"Synechocystis FAME: {name}")
for name, (v, comp) in legacy_map.LEGACY.items():
    for x in (v if isinstance(v, list) else [v] if v else []):
        aliases[x].add(f"MLL v1: {name}")
for e in ENT.values():
    e["aliases"] = sorted(aliases.get(e["id"], []))
    if e["xrefs"].get("kegg_map"):
        e["aliases"].insert(0, "KEGG: " + e["name"])


def ancestors(i):
    seen, stack = [], list(ENT[i]["part_of"])
    while stack:
        p = stack.pop(0)
        if p in ENT and p not in seen:
            seen.append(p); stack.extend(ENT[p]["part_of"])
    return seen


def related(a, b):
    return a == b or a in ancestors(b) or b in ancestors(a)


def lift(i):
    """nearest pathway-level (or region/category) representative"""
    e = ENT[i]
    if e["type"] in ("pathway", "region", "category"):
        return i
    for p in ancestors(i):
        if ENT[p]["type"] in ("pathway", "region", "category"):
            return p
    return i


def category_of(i):
    for p in [i] + ancestors(i):
        if ENT[p]["type"] == "category":
            return p
    return None


# ------------------------------------------------------------------ geometry helpers
DIR8 = ["above", "above_right", "right", "below_right", "below", "below_left", "left", "above_left"]
COMPASS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
VEC = {"above": (0, 1), "below": (0, -1), "right": (1, 0), "left": (-1, 0),
       "above_right": (1, 1), "above_left": (-1, 1), "below_right": (1, -1), "below_left": (-1, -1),
       "adjacent_right": (1, 0), "adjacent_left": (-1, 0)}


def bearing(dx, dy):  # dy: north positive
    return (math.degrees(math.atan2(dx, dy)) + 360) % 360


def dir8(b):
    return DIR8[int(((b + 22.5) % 360) // 45)]


def unit(v):
    n = math.hypot(*v)
    return (v[0] / n, v[1] / n) if n else (0.0, 0.0)


# ------------------------------------------------------------------ sources
SOURCES = {
    "kegg_01100": dict(title="KEGG global metabolic map 01100 (Metabolic pathways)", kind="map_measured",
                       url="https://www.kegg.jp/pathway/map01100",
                       data="KGML ko01100.xml (KGML v0.7.1, created 2012-11-02) as distributed in Biopython Tests/KEGG",
                       method="pathway label coordinates (one per KEGG map) and single-occurrence compound circles for hubs",
                       caveats="Label positions approximate region centres; KEGG layout as of 2012; reference (all-organism) map."),
    "human_gem_maps": dict(title="Metabolic Atlas / Human-GEM 2D compartment maps (Escher export, Human-GEM 2.1.1)", kind="map_measured",
                           url="https://github.com/SysBioChalmers/Human-maps",
                           data="compartment/escher/*.json; reaction subsystems from Human-GEM.yml (main branch)",
                           method="median of reaction-label positions per subsystem (>=3 reactions); hubs from single metabolite nodes",
                           caveats="12 separate canvases (cytosol split into 5 parts); relations only within a canvas; human only."),
    "escher_bigg_maps": dict(title="Escher example maps (BiGG): E. coli core/iJO1366, RECON1, iMM904", kind="map_measured",
                             url="https://github.com/escher/escher.github.io/tree/master/1-0-0/6/maps",
                             data="12 maps; reaction subsystems from iJO1366 (cobrapy data) or Human-GEM BiGG cross-references",
                             method="median of reaction-label positions per subsystem (>=2 reactions); primary metabolite nodes for hubs",
                             caveats="mostly central metabolism; subsystem assignments borrowed from iJO1366/Human-GEM."),
    "cbmviz_synechocystis_map": dict(title="Synechocystis sp. PCC 6803 hand-drawn map (CBMViz repository)", kind="map_measured",
                                     url="https://github.com/cnapy-org/metabolic-pathway-maps/tree/master/Synechocystis",
                                     data="Synechocystis.svg + Synechocystis-fame.v1.xml SUBSYSTEM notes",
                                     method="median of reaction element positions per subsystem",
                                     caveats="single organism (cyanobacterium); includes photosynthesis and Calvin cycle."),
    "cbmviz_generic_map": dict(title="Generic Metabolic Map 1.0 ('Mothermap', CBMViz repository other_maps)", kind="map_measured",
                               url="https://github.com/cnapy-org/metabolic-pathway-maps/tree/master/other_maps",
                               data="Generic_Metabolic_Map_1.0.svg (BiGG metabolite ids)",
                               method="median position of iJO1366 marker metabolites (>=60% of a metabolite's reactions in one subsystem)",
                               caveats="subsystems inferred indirectly from marker metabolites; E. coli subsystem scheme."),
    "metacyc_cellular_overview": dict(title="Pathway Tools / MetaCyc cellular overview conventions", kind="literature_convention",
                                      url="https://pmc.ncbi.nlm.nih.gov/articles/PMC7911265",
                                      data="Paley & Karp 2006 NAR 34:3771; Paley et al. 2021 Metabolites 11:64",
                                      method="documented layout convention", caveats="coarse, role-level only"),
    "knowledge_textbook": dict(title="Textbook / wall-chart conventions (assistant knowledge)", kind="knowledge",
                               url=None, data="knowledge.py HUB_DIRECTIONS, CYCLE_LAYOUTS",
                               method="expert convention", caveats="not measured; verify against preferred maps"),
    "knowledge_biochemistry": dict(title="Biochemical topology (assistant knowledge)", kind="knowledge", url=None,
                                   data="knowledge.py RELATIONS", method="pathway connectivity via shared metabolites",
                                   caveats="orientation-free; taxa scopes are coarse"),
    "mll_v1": dict(title="MLL Global Placement Directions v1.0.0 (user supplied)", kind="knowledge", url=None,
                   data="placement_directions.json (229 rules)", method="re-expressed in v2 vocabulary",
                   caveats="names mapped by hand; composite names expanded; placeholders moved to policies"),
}
STRENGTH_W = {"hard": 1.0, "strong": 0.8, "medium": 0.6, "weak": 0.3}

# ------------------------------------------------------------------ measured observations
points = json.load(open(f"{W}/build/points.json"))
by_canvas = collections.defaultdict(list)
for p in points:
    if p["spread"] <= 0.12:  # diffuse subsystems have no meaningful single position
        by_canvas[(p["source"], p["canvas"])].append(p)

observations, placements = [], []
oid = 0
for (src, can), pts in sorted(by_canvas.items()):
    if len(pts) < 2:
        continue
    xy = np.array([[p["x"], p["y"]] for p in pts], float)
    lo, hi = xy.min(0), xy.max(0)
    span = np.where(hi - lo > 0, hi - lo, 1.0)
    diag = float(math.hypot(*span))
    # absolute placement in this canvas (nine-cell grid, north up)
    for p in pts:
        fx = (p["x"] - lo[0]) / span[0]; fy = 1 - (p["y"] - lo[1]) / span[1]
        col = "W" if fx < 1 / 3 else "E" if fx > 2 / 3 else ""
        row = "N" if fy > 2 / 3 else "S" if fy < 1 / 3 else ""
        placements.append(dict(source=src, canvas=can, entity=p["entity"], x_frac=round(fx, 3), y_frac=round(fy, 3),
                               region=(row + col) or "C", kind=p["kind"], n=p["n"]))
    # neighbour pairs: Delaunay edges (all pairs for tiny canvases)
    pairs = set()
    if len(pts) <= 4:
        pairs = {(i, j) for i in range(len(pts)) for j in range(i + 1, len(pts))}
    else:
        jit = xy + np.random.default_rng(0).normal(0, 1e-6 * diag, xy.shape)
        for s in Delaunay(jit).simplices:
            for a in range(3):
                for b in range(a + 1, 3):
                    pairs.add(tuple(sorted((int(s[a]), int(s[b])))))
    for i, j in sorted(pairs):
        a, b = pts[i], pts[j]
        if related(a["entity"], b["entity"]):
            continue
        if a["entity"] > b["entity"]:
            a, b = b, a
        dx = (b["x"] - a["x"]) / diag; dy = -(b["y"] - a["y"]) / diag
        d = math.hypot(dx, dy)
        if d > 0.45 or d == 0:
            continue
        sep = d / (a["spread"] + b["spread"] + 0.02)
        conf = round(min(1.0, sep / 3), 3)
        oid += 1
        observations.append(dict(
            id=f"OBS{oid:05d}", source=src, canvas=can, anchor=a["entity"], target=b["entity"],
            direction=dir8(bearing(dx, dy)), bearing_deg=round(bearing(dx, dy), 1),
            dx=round(dx, 4), dy=round(dy, 4), distance=round(d, 4), confidence=conf,
            evidence=f"{a['kind']}/{b['kind']}; n={a['n']}/{b['n']}"))

# category centroids per canvas -> coarse observations
for (src, can), pts in sorted(by_canvas.items()):
    cats = collections.defaultdict(list)
    for p in pts:
        c = category_of(p["entity"])
        if c and ENT[p["entity"]]["type"] != "metabolite_hub":
            cats[c].append((p["x"], p["y"]))
    cats = {c: v for c, v in cats.items() if len(v) >= 2}
    if len(cats) < 2:
        continue
    xy = np.array([q for v in cats.values() for q in v]); span = xy.max(0) - xy.min(0)
    diag = float(math.hypot(*span)) or 1.0
    cen = {c: np.mean(v, 0) for c, v in cats.items()}
    ks = sorted(cen)
    for i in range(len(ks)):
        for j in range(i + 1, len(ks)):
            dx = (cen[ks[j]][0] - cen[ks[i]][0]) / diag; dy = -(cen[ks[j]][1] - cen[ks[i]][1]) / diag
            d = math.hypot(dx, dy)
            if d < 0.03:
                continue
            oid += 1
            observations.append(dict(id=f"OBS{oid:05d}", source=src, canvas=can, anchor=ks[i], target=ks[j],
                                     direction=dir8(bearing(dx, dy)), bearing_deg=round(bearing(dx, dy), 1),
                                     dx=round(dx, 4), dy=round(dy, 4), distance=round(d, 4),
                                     confidence=round(min(1.0, d / 0.15), 3),
                                     evidence=f"category centroids; n={len(cats[ks[i]])}/{len(cats[ks[j]])}"))

# ------------------------------------------------------------------ knowledge relations
relations = []
for k, (a, t, rel, via, taxa, note) in enumerate(knowledge.RELATIONS, 1):
    for x in [a, t] + via:
        assert x in ENT, f"unknown entity {x}"
    relations.append(dict(id=f"REL{k:04d}", source="knowledge_biochemistry", anchor=a, target=t, relationship=rel,
                          directed=rel in ("FEEDS", "COFACTOR_SUPPLY", "ENERGY_COUPLING", "TRANSPORT"),
                          via=via, scope=dict(taxa=taxa), note=note))

direction_rules = []
for k, (a, t, d, s, note) in enumerate(knowledge.HUB_DIRECTIONS, 1):
    assert a in ENT and t in ENT, (a, t)
    direction_rules.append(dict(id=f"DIR{k:04d}", source="knowledge_textbook", anchor=a, target=t, direction=d,
                                strength=s, scope=dict(taxa=["all"]), note=note))
for c in knowledge.CYCLE_LAYOUTS:
    for m in c["order"] + list(c["entry_points"].values()) + list(c["entry_points"].keys()):
        assert m in ENT, m

# ------------------------------------------------------------------ legacy rules
legacy = json.load(open("/mnt/user-data/uploads/placement_directions.json"))
legacy_rules, policies, legacy_index = [], [], []
for r in legacy["rules"]:
    A, ca = legacy_map.LEGACY[r["anchor_subsystem"]]
    T, ct = legacy_map.LEGACY[r["target_subsystem"]]
    rel = legacy_map.REL[r["relationship"]]
    if r["id"] in legacy_map.COFACTOR:
        rel = "COFACTOR_SUPPLY"
    if A is None or T is None:
        policies.append(dict(id=r["id"].replace("GPR", "POL"), legacy_id=r["id"], relationship=rel,
                             placement=r["target_direction_from_anchor"], strength=r["strength"],
                             statement=r["rationale"]))
        legacy_index.append(dict(legacy_id=r["id"], status="policy"))
        continue
    As = A if isinstance(A, list) else [A]
    Ts = T if isinstance(T, list) else [T]
    made = []
    for a in As:
        for t in Ts:
            if a == t:
                continue
            anchor, target, d = a, t, r["target_direction_from_anchor"]
            if rel == "FEEDS" and r["id"] in legacy_map.REVERSED_FEEDS:
                rule_rel_dir = "target_to_anchor"
            else:
                rule_rel_dir = "anchor_to_target"
            rid = f"{r['id']}{'' if len(As) * len(Ts) == 1 else chr(97 + len(made))}"
            legacy_rules.append(dict(id=rid, legacy_id=r["id"], source="mll_v1", anchor=anchor, target=target,
                                     direction=d, relationship=rel, flow=rule_rel_dir if rel == "FEEDS" else None,
                                     strength=r["strength"], scope=dict(taxa_text=r["scope"],
                                                                        compartments=[c for c in (ca, ct) if c]),
                                     note=r["rationale"]))
            made.append(rid)
    legacy_index.append(dict(legacy_id=r["id"], status="rule", v2_ids=made))

# ------------------------------------------------------------------ consensus
votes = collections.defaultdict(lambda: collections.defaultdict(list))  # pair -> source -> [(vx,vy,w,detail)]


def vote(a, t, vx, vy, w, src, detail, level):
    if a == t or related(a, t):
        return
    if a > t:
        a, t, vx, vy = t, a, -vx, -vy
    votes[(level, a, t)][src].append((vx, vy, w, detail))


for o in observations:
    u = unit((o["dx"], o["dy"]))
    for level, f in (("exact", lambda x: x), ("pathway", lift)):
        vote(f(o["anchor"]), f(o["target"]), *u, o["confidence"], o["source"], f"{o['canvas']}:{o['direction']}", level)
for r in direction_rules + legacy_rules:
    if r["direction"] not in VEC:
        continue
    u = unit(VEC[r["direction"]])
    for level, f in (("exact", lambda x: x), ("pathway", lift)):
        vote(f(r["anchor"]), f(r["target"]), *u, STRENGTH_W[r["strength"]], r["source"], f"{r['id']}:{r['direction']}", level)

consensus = []
for (level, a, t), bysrc in sorted(votes.items()):
    per = {}
    for src, vs in bysrc.items():
        sw = sum(v[2] for v in vs) or 1e-9
        mx = sum(v[0] * v[2] for v in vs) / sw; my = sum(v[1] * v[2] for v in vs) / sw
        per[src] = dict(vec=unit((mx, my)), weight=round(min(1.0, sw), 3), n=len(vs),
                        within_source_R=round(math.hypot(mx, my), 3), details=[v[3] for v in vs][:6])
    W_ = sum(p["weight"] for p in per.values())
    mx = sum(p["vec"][0] * p["weight"] for p in per.values()) / W_
    my = sum(p["vec"][1] * p["weight"] for p in per.values()) / W_
    R = math.hypot(mx, my)
    ns = len(per)
    xs = [np.sign(p["vec"][0]) for p in per.values() if abs(p["vec"][0]) > 0.38]
    ys = [np.sign(p["vec"][1]) for p in per.values() if abs(p["vec"][1]) > 0.38]
    if ns == 1:
        status = "single_source"
    elif R >= 0.85:
        status = "agreement"
    elif R >= 0.5:
        status = "partial"
    else:
        status = "conflict"
    measured = sum(1 for s in per if SOURCES[s]["kind"] == "map_measured")
    if status == "agreement" and ns >= 3:
        sugg = "strong"
    elif status == "agreement":
        sugg = "medium"
    elif status in ("partial", "single_source"):
        sugg = "weak"
    else:
        sugg = "none"
    b = bearing(mx, my)
    consensus.append(dict(
        level=level, anchor=a, target=t,
        direction=dir8(b) if R > 0.2 else "undetermined", bearing_deg=round(b, 1), agreement_R=round(R, 3),
        n_sources=ns, n_map_sources=measured, status=status, suggested_strength=sugg,
        x_order=("target_right" if sum(xs) > 0 else "target_left" if sum(xs) < 0 else "undetermined") if xs else "aligned",
        x_votes=f"{int(sum(1 for v in xs if v > 0))}R/{int(sum(1 for v in xs if v < 0))}L",
        y_order=("target_above" if sum(ys) > 0 else "target_below" if sum(ys) < 0 else "undetermined") if ys else "aligned",
        y_votes=f"{int(sum(1 for v in ys if v > 0))}A/{int(sum(1 for v in ys if v < 0))}B",
        per_source={s: dict(direction=dir8(bearing(*p["vec"])), bearing_deg=round(bearing(*p["vec"]), 1),
                            weight=p["weight"], n=p["n"], within_source_R=p["within_source_R"], examples=p["details"])
                    for s, p in sorted(per.items())}))

# ------------------------------------------------------------------ assemble
cats = collections.Counter(c["status"] for c in consensus if c["level"] == "pathway")
doc = dict(
    language="MLL Global Placement Directions",
    version="2.0.0",
    description=("Multi-source catalogue of placement evidence for metabolic subsystems on overview maps. "
                 "Evidence is kept per source; inconsistencies between maps are preserved and summarised in "
                 "'consensus' rather than resolved."),
    coordinate_frame=dict(x="east (right) positive", y="north (up) positive",
                          bearing="degrees clockwise from north", distance="fraction of the canvas diagonal",
                          direction_semantics="'direction' always gives the position of TARGET relative to ANCHOR"),
    direction_vocabulary=dict(compass=DIR8, semantic=["adjacent", "adjacent_left", "adjacent_right", "center",
                              "across_compartment_boundary", "adjacent_across_boundary", "toward_center", "outward",
                              "downstream_along_flow", "fan_out_from_anchor", "parallel_neighbourhood", "cycle_periphery",
                              "same_compartment_region", "supporting_link_not_forced_adjacent", "regulatory_overlay",
                              "global_support_link", "outward_or_lower"]),
    relationship_vocabulary=dict(
        FEEDS="directed: material flows from anchor into target (via lists the connecting metabolites)",
        SHARES_HUB="undirected: both use the listed branch-point metabolites; attach at them",
        ALTERNATIVE_ROUTE="undirected: alternative routes between shared endpoints; draw in parallel",
        REVERSE_OF="undirected: opposing directions of (largely) the same transformations; draw side by side",
        SAME_FAMILY="undirected: functionally related, keep contiguous",
        COFACTOR_SUPPLY="directed: anchor makes a cofactor the target needs; weak, never pulls layouts together",
        ENERGY_COUPLING="directed: anchor supplies ATP/reductant/proton motive force to target",
        TRANSPORT="directed: link crosses a compartment boundary; transporter sits on the boundary",
        SAME_COMPARTMENT="undirected: co-localised", REGULATES="overlay only"),
    strength_definitions=legacy.get("strength_definitions"),
    consensus_definitions=dict(
        agreement_R="length of the weighted mean unit vector over sources (1 = all sources point the same way)",
        status="single_source | agreement (R>=0.85) | partial (0.5<=R<0.85) | conflict (R<0.5)",
        suggested_strength="strong: agreement with >=3 sources; medium: agreement with 2; weak: partial or single source; none: conflict",
        levels="exact = as observed; pathway = modules and hubs lifted to their pathway so that sources of different granularity meet"),
    sources=SOURCES,
    entities=sorted(ENT.values(), key=lambda e: (["category", "region", "pathway", "module", "metabolite_hub"].index(e["type"]), e["id"])),
    relations=relations,
    direction_rules=direction_rules + legacy_rules,
    cycle_layouts=knowledge.CYCLE_LAYOUTS,
    role_conventions=knowledge.ROLE_CONVENTIONS,
    policies=policies,
    observations=observations,
    absolute_placements=placements,
    consensus=consensus,
    legacy_index=legacy_index,
    statistics=dict(entities=len(ENT), relations=len(relations), direction_rules=len(direction_rules) + len(legacy_rules),
                    observations=len(observations), absolute_placements=len(placements), consensus_pairs=len(consensus),
                    consensus_pathway_level_status=dict(cats)),
)
os.makedirs(OUT, exist_ok=True)
json.dump(doc, open(f"{OUT}/placement_directions_v2.json", "w"), indent=1, ensure_ascii=False)
with open(f"{OUT}/consensus_pairs.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["level", "anchor", "target", "direction", "bearing_deg", "agreement_R", "status", "suggested_strength",
                "n_sources", "n_map_sources", "x_order", "x_votes", "y_order", "y_votes", "per_source"])
    for c in consensus:
        w.writerow([c["level"], c["anchor"], c["target"], c["direction"], c["bearing_deg"], c["agreement_R"], c["status"],
                    c["suggested_strength"], c["n_sources"], c["n_map_sources"], c["x_order"], c["x_votes"],
                    c["y_order"], c["y_votes"],
                    "; ".join(f"{s}:{p['direction']}" for s, p in c["per_source"].items())])
print(json.dumps(doc["statistics"], indent=1))
