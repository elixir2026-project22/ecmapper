"""Extract entity positions (subsystems, modules, hubs) from all map sources.

Output: points.json = list of dicts
  {source, canvas, entity, x, y, n, spread, kind}
Coordinates are in the source's screen frame (x right, y DOWN).
"""
import collections, csv, glob, json, math, os, re, statistics, sys
sys.path.insert(0, os.path.dirname(__file__))
import vocab

W = "/home/claude"
ENT = vocab.build_entities()
HUB_BY_BIGG = {}
HUB_BY_KEGG = {}
for e in ENT.values():
    if e["type"] == "metabolite_hub":
        for b in e["xrefs"]["bigg_metabolite"]:
            HUB_BY_BIGG[b] = e["id"]
        HUB_BY_KEGG[e["xrefs"]["kegg_compound"]] = e["id"]
KEGG_MAP = {e["xrefs"]["kegg_map"][3:]: e["id"] for e in ENT.values() if e["xrefs"].get("kegg_map")}

points = []


def robust_point(xy):
    xs = [p[0] for p in xy]; ys = [p[1] for p in xy]
    mx, my = statistics.median(xs), statistics.median(ys)
    spread = statistics.median([math.hypot(x - mx, y - my) for x, y in xy]) if len(xy) > 1 else 0.0
    return mx, my, spread


def add_group(source, canvas, diag, groups, kind, min_n=1, max_rel_spread=None):
    for ent, xy in groups.items():
        if ent is None or len(xy) < min_n:
            continue
        x, y, s = robust_point(xy)
        if max_rel_spread is not None and len(xy) > 1 and s / diag > max_rel_spread:
            continue
        points.append(dict(source=source, canvas=canvas, entity=ent, x=round(x, 1), y=round(y, 1),
                           n=len(xy), spread=round(s / diag, 4), kind=kind))


def strip_comp(bid):
    return re.sub(r"_[a-z]{1,2}$", "", bid)


# ---------------- KEGG global map (KGML ko01100) ----------------
s = open(f"{W}/ko01100.xml").read()
xs = [int(v) for v in re.findall(r' x="(\d+)"', s)]; ys = [int(v) for v in re.findall(r' y="(\d+)"', s)]
diag = math.hypot(max(xs) - min(xs), max(ys) - min(ys))
g = collections.defaultdict(list)
for num, name, x, y in re.findall(r'name="path:ko(\d+)" type="map".*?<graphics name="([^"]*)"[^>]*x="(\d+)" y="(\d+)"', s, re.S):
    if num in KEGG_MAP:
        g[KEGG_MAP[num]].append((int(x), int(y)))
    else:
        print("KEGG unmapped", num, name)
add_group("kegg_01100", "global", diag, g, "label")
g = collections.defaultdict(list)
for cid, x, y in re.findall(r'name="cpd:(C\d+)" type="compound".*?x="(\d+)" y="(\d+)"', s, re.S):
    if cid in HUB_BY_KEGG:
        g[HUB_BY_KEGG[cid]].append((int(x), int(y)))
add_group("kegg_01100", "global", diag, g, "hub", max_rel_spread=0.01)

# ---------------- Human-GEM maps (Metabolic Atlas, Escher format) ----------------
y = open(f"{W}/hgem.yml").read()
rxn_sub = {}
for rid, body in re.findall(r"- id: (MAR\d+)\n(.*?)(?=\n  - !!omap|\Z)", y, re.S):
    m = re.search(r"- subsystem:\n      - ([^\n]+)", body)
    if m:
        rxn_sub[rid] = m.group(1).strip()
met_bigg = {}
bigg_rxn_sub = {}
with open(f"{W}/hgem_mets.tsv") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        met_bigg[r["mets"]] = r["metBiGGID"]
with open(f"{W}/hgem_rxns.tsv") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        if r["rxnBiGGID"] and r["rxns"] in rxn_sub:
            bigg_rxn_sub[r["rxnBiGGID"]] = vocab.map_human_gem(rxn_sub[r["rxns"]])
for fn in sorted(glob.glob(f"{W}/hm/compartment/escher/*.json")):
    canvas = os.path.basename(fn)[:-5]
    m = json.load(open(fn))[1]
    diag = math.hypot(m["canvas"]["width"], m["canvas"]["height"])
    g = collections.defaultdict(list)
    for r in m["reactions"].values():
        sub = rxn_sub.get(r["bigg_id"])
        if sub:
            g[vocab.map_human_gem(sub)].append((r["label_x"], r["label_y"]))
    add_group("human_gem_maps", canvas, diag, g, "reactions", min_n=3)
    g = collections.defaultdict(list)
    for n in m["nodes"].values():
        if n["node_type"] == "metabolite":
            b = met_bigg.get(n["bigg_id"])
            if b in HUB_BY_BIGG:
                g[HUB_BY_BIGG[b]].append((n["x"], n["y"]))
    add_group("human_gem_maps", canvas, diag, g, "hub", max_rel_spread=0.01)

# ---------------- iJO1366 model (subsystems; metabolite markers) ----------------
x = open(f"{W}/ijo.xml").read()
ijo_rxn_sub = {}
for gname, body in re.findall(r'<groups:group [^>]*groups:name="([^"]*)"[^>]*>(.*?)</groups:group>', x, re.S):
    for rid in re.findall(r'groups:idRef="R_([^"]+)"', body):
        ijo_rxn_sub[rid] = vocab.IJO1366.get(gname)
met_subs = collections.defaultdict(collections.Counter)
for rid, body in re.findall(r'<reaction [^>]*id="R_([^"]+)"[^>]*>(.*?)</reaction>', x, re.S):
    sub = ijo_rxn_sub.get(rid)
    if not sub:
        continue
    for sp in set(re.findall(r'species="M_([^"]+)"', body)):
        met_subs[strip_comp(sp)][sub] += 1
CURRENCY = set("h h2o atp adp amp nad nadh nadp nadph pi ppi co2 o2 coa nh4 q8 q8h2 mqn8 mql8 fad fadh2 h2o2 "
               "gtp gdp udp utp ctp cdp hco3 so4 so3 h2s glu__L akg gln__L accoa pyr".split())
markers = {}
for met, c in met_subs.items():
    if met in CURRENCY:
        continue
    tot = sum(c.values()); sub, k = c.most_common(1)[0]
    if tot >= 2 and k / tot >= 0.6:
        markers[met] = sub
json.dump(markers, open(f"{W}/build/ijo_markers.json", "w"), indent=0)


def bigg_rxn_subsystem(rid):
    return ijo_rxn_sub.get(rid) or bigg_rxn_sub.get(rid)


# ---------------- Escher BiGG maps ----------------
for fn in sorted(glob.glob(f"{W}/escher/*.json")):
    canvas = os.path.basename(fn)[:-5]
    m = json.load(open(fn))[1]
    diag = math.hypot(m["canvas"]["width"], m["canvas"]["height"])
    g = collections.defaultdict(list)
    for r in m["reactions"].values():
        sub = bigg_rxn_subsystem(r["bigg_id"])
        if sub:
            g[sub].append((r["label_x"], r["label_y"]))
    add_group("escher_bigg_maps", canvas, diag, g, "reactions", min_n=2)
    g = collections.defaultdict(list)
    for n in m["nodes"].values():
        if n["node_type"] == "metabolite" and n.get("node_is_primary", True):
            b = strip_comp(n["bigg_id"])
            if b in HUB_BY_BIGG:
                g[HUB_BY_BIGG[b]].append((n["x"], n["y"]))
    add_group("escher_bigg_maps", canvas, diag, g, "hub", max_rel_spread=0.01)

# ---------------- SVG maps from the CBMViz repository ----------------
from svgelements import SVG


def svg_positions(path, prefix):
    from svgelements import Text
    svg = SVG.parse(path, reify=True)
    out = collections.defaultdict(list)
    for el in svg.elements():
        vals = getattr(el, "values", None)
        if not vals:
            continue
        i = vals.get("id")
        if not (i and i.startswith(prefix)):
            continue
        if isinstance(el, Text):
            p = (float(el.x), float(el.y))
        else:
            try:
                bb = el.bbox()
            except Exception:
                bb = None
            if not bb:
                continue
            p = ((bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2)
        out[re.sub(r"-\d+$", "", i)].append(p)
    return out, float(svg.width or 0), float(svg.height or 0)


# Synechocystis map + FAME model subsystems
fame = open(f"{W}/cbm/Synechocystis/Synechocystis-fame.v1.xml").read()
fame_sub = {}
for rid, body in re.findall(r'<reaction [^>]*id="R_([^"]+)"[^>]*>(.*?)</reaction>', fame, re.S):
    m = re.search(r'SUBSYSTEM" value="([^"]*)"', body)
    if m:
        fame_sub[rid] = vocab.FAME_SYNECHOCYSTIS.get(m.group(1))
for prefix, kind in (("R_", "reactions"), ("M_", "hub")):
    pos, w, h = svg_positions(f"{W}/cbm/Synechocystis/Synechocystis.svg", prefix)
    allxy = [p for v in pos.values() for p in v]
    diag = math.hypot(max(p[0] for p in allxy) - min(p[0] for p in allxy), max(p[1] for p in allxy) - min(p[1] for p in allxy))
    g = collections.defaultdict(list)
    for k, v in pos.items():
        if kind == "reactions":
            sub = fame_sub.get(k[2:])
            if sub:
                g[sub].extend(v)
        else:
            b = strip_comp(k[2:])
            if b in HUB_BY_BIGG:
                g[HUB_BY_BIGG[b]].extend(v)
    add_group("cbmviz_synechocystis_map", "whole", diag, g, kind, min_n=2,
              max_rel_spread=0.01 if kind == "hub" else None)

# Generic "Mothermap" (CBMViz other_maps): marker metabolites + hubs
pos, w, h = svg_positions(f"{W}/cbm/other_maps/Generic_Metabolic_Map_1.0.svg", "M_")
allxy = [p for v in pos.values() for p in v]
diag = math.hypot(max(p[0] for p in allxy) - min(p[0] for p in allxy), max(p[1] for p in allxy) - min(p[1] for p in allxy))
g = collections.defaultdict(list); gh = collections.defaultdict(list)
for k, v in pos.items():
    b = strip_comp(k[2:])
    if b in markers:
        g[markers[b]].extend(v)
    if b in HUB_BY_BIGG:
        gh[HUB_BY_BIGG[b]].extend(v)
add_group("cbmviz_generic_map", "whole", diag, g, "marker_metabolites", min_n=3)
add_group("cbmviz_generic_map", "whole", diag, gh, "hub", max_rel_spread=0.01)

# canvas diagonals for later normalisation
json.dump(points, open(f"{W}/build/points.json", "w"), indent=0)
c = collections.Counter((p["source"], p["canvas"]) for p in points)
for k, v in sorted(c.items()):
    print(k, v)
print("total points", len(points), "entities", len({p['entity'] for p in points}))
